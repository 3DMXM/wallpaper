﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Threading;



namespace sitemap自动生成
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            
        }
               

        private void button1_Click(object sender, EventArgs e)      //生成
        {
            int a = Convert.ToInt32(ID.Text);     //获取最新的ID
           // string b = "";                           //申明变量，用来存放文本内容
            int d = 30000;                       //设置起始ID
            int c = a - d;                      //计算目前Mod数量
            string url = "";                          //用来存放内部url节点
            string t = DateTime.Now.ToShortDateString().ToString(); //获取当前时间
            int g=30001;            //起始ID

            if (a<d)
            {
                MessageBox.Show("请输入正确的ID", "ID错误");
            }
            /*
              for (int i = 0; i < c; i++)
              {
                  url = "\n\t<url>\n\t\t<loc>https://mod.3dmgame.com/mod/" + g + "</loc>\n\t\t<lastmod>" + f + "</lastmod>\n\t\t<changefreq>always</changefreq>\n\t\t<priority>0.8</priority>\n\t</url>\n";                  
                  b += url;
                  g++;


                /*
                //对xml文件内部修改
                XmlDocument xml = new XmlDocument();    //初始化一个xml实例
                xml.Load("sitemap.xml");            //指定文件
                XmlNode root = xml.SelectSingleNode("urlset");  //指定一个节点
                XmlElement node = xml.CreateElement("url");    //生成一个新的节点
                root.AppendChild(node);         //将节点加到指定节点下，作为其子节点
                node.SetAttribute("id", "11111");   ////为指定节点的新建属性并赋值
                
            }*/



            /*生成“sitemap.xml”文件并在里面添加内容“b”*/


            string b = "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">";
            for (int i = 0; i < c; i++)
            {
                url = "\n\t<url>\n\t\t<loc>https://mod.3dmgame.com/mod/" + g + "</loc>\n\t\t<lastmod>" + t + "</lastmod>\n\t\t<changefreq>always</changefreq>\n\t\t<priority>0.8</priority>\n\t</url>\n";
                b += url;
                g++;
                
            }
            string u = " </urlset> ";
            string fileName = @"sitemap.xml";
            FileStream fs = File.Create(fileName);
            Byte[] info = new UTF8Encoding(true).GetBytes(b+url+u);
            fs.Write(info, 0, info.Length);
            fs.Flush();
            fs.Close();

            Thread fThread = new Thread(new ThreadStart(SleepT));   //进度条
            fThread.Start();

            string z = b + url + u;
            textBox1.Text = z;



        }

        private delegate void SetPos(int ipos, string vinfo);   //代理
        private void SetTextMesssage(int ipos, string vinfo)
        {
            if (this.InvokeRequired)
            {
                SetPos setpos = new SetPos(SetTextMesssage);
                this.Invoke(setpos, new object[] { ipos, vinfo });
            }
            else
            {
                this.label1.Text = ipos.ToString() + "/100%";
                this.progressBar1.Value = Convert.ToInt32(ipos);
                this.textBox1.AppendText(vinfo);
            }
        }
        private void SleepT()
        {
            for (int i = 0; i < 500; i++)
            {
                System.Threading.Thread.Sleep(10);
                SetTextMesssage(100 * i / 500, i.ToString() + "\r\n");
            }
        }

        /*进度条*/

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)      //追加
        {
            int a = Convert.ToInt32(ID.Text);     //获取最新的ID
                                                  // string b = "";                           //申明变量，用来存放文本内容
            int d = 30000;                       //设置起始ID
            int c = a - d;                      //计算目前Mod数量
           // string url = "";                          //用来存放内部url节点
            string t = DateTime.Now.ToShortDateString().ToString(); //获取当前时间
            int g = 30001;            //起始ID

            if (a < d)
            {
                MessageBox.Show("请输入正确的ID", "ID错误");
            }


            
           
            //初始化一个xml实例
            XmlDocument xml = new XmlDocument();
            //导入指定xml文件
            xml.Load("sitemap.xml");
            //指定一个节点
            XmlNode root = xml.SelectSingleNode("urlset");
            //获取节点下所有直接子节点
            XmlNodeList childlist = root.ChildNodes;

            //生成一个新节点
            XmlElement node =xml.CreateElement("url");

            for (int i = 0; i < c; i++) //添加内容
            {
                //获取同名同级节点集合
               // XmlNodeList nodelist = xml.SelectNodes("url");
                
                
                //将节点加到指定节点下，作为其子节点
                root.AppendChild(node);

                //为指定节点的新建属性并赋值
                node.SetAttribute("loc", "https://mod.3dmgame.com/mod/" + g);
                //为指定节点添加子节点
                root.AppendChild(node);
                node.SetAttribute("lastmod", t);

                root.AppendChild(node);
                node.SetAttribute("changefreq", "always");

                root.AppendChild(node);
                node.SetAttribute("priority", "0.6");
            }
            

            
            //获取指定节点中的文本
            string content = node.InnerText;
            //保存XML文件
            xml.Save("xml文件存储的路径path");




        }
    }
}

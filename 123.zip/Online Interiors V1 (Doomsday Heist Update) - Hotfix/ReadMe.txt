INFORMATION
This mod is a sort of add-on for the Open Interiors by NewTheft. This was built ontop of the original Online Interiors by Alex106.

SCRIPT HOOK V "CAN'T FIND NATIVE" ERROR NOTE
If you get the error "FATAL: Can't find native 0x31D23FC8CCD18DC3" you need to update both your game (to the version 1180.2) and the Script Hook V

NOTE #1
With this script it's not possible to:
Enable the MP Map. Look for "loadMultiplayerMap=0" and change it to "loadMultiplayerMap=1" in the OpenInteriors.ini to enable it
Customize the Maze Bank Tower Office. Look for "officeStyle" in the OpenInteriors.ini to change the interior
Customize the Biker Clubhouses. Look for "motorcycleClubStyle" in the OpenInteriors.ini to customize the interior style
Teleport to the Maze Bank Tower Office, Biker Clubhouses and Warehouses
Customize your vehicle at the MBT Mod Garage
Save vehicle at the MBT 60 Car Garage/Hangar

Why? Because those features are already avaible with Open Interiors

NOTE #2
For any problem such as interiors/interior decals not loading, blips not showing or something else not working, make sure to post: 
Game version
Script Hook V version
Script Hook V NET version
Script Hook V NET log

NOTE #3
If the Assistant isn't spawning (or it's just standing) it's because the script has crashed. I know that and once i finish with the main script and it's (most probably still laying around) problems i will fix it 

FEATURES
Player Facility with customization
Government Building Server Room
Satelite IAA Facility
Submarine with exterior prop
Chilliad Launch Base with secret door prop added in tunnel
Facility and Chilliad Silo hatches enabled
Sprinting in all interiors (enabled by default)
Motorcycle Club name, and Clubhouse Laptop screen to the Clubhouse interiors
CEO Organization name, and Office Desktop screen to the Maze Bank office
Orbital Cannon scaleform to the table and displays in the Facility
Activated large screen in Facility planning room
Added Privacy Glass to Facility Lounge and Facility Bedrooom
Added audio to metal detectors in the Player Facility and IAA Facility
Ship camera animation for Aircraft Carrier, Heist Yacht, all 36 custom Yachts, Gun Running Yacht, and Submarine interior.
Interior props for the Biker Clubhouses, Warehouses, Maze Bank Tower Office, and Facility
Vehicle Warehouse
Maze Bank Tower 60 Car Garage
Maze Bank Tower Mod Garage
Bunker
Bunker Hatches
Hangar (disabled by default)
Vagos grave (closed)
Gunrunning Yacht
10 Car Garage (MP Map variant)
Doors at the Vagos warehouse (El Burro Heights)
Lost MC Clubhouse (East Vinewood)
Fort Zancudo Tower elevator teleport
Director Mode Casting Trailer teleport (there is a marker at a trailer just outside Solomon's office)
Ability to request a helicopter (Buzzard or Cargobob) from the Assistant desk (MBT office)
Ability to sleep at the Maze Bank Tower office/Vehicle Warehouse/Bunker/Hangar (time will advance of 6 hours, wanted level will be removed, blood wounds will be cleaned and wet clothes will be dried)
Water around the aircraft carrier/Heist yacht/Gunrunning yacht lowers when being near
Assistant at the Maze Bank Tower Office
Covered cars inside the Vehicle Warehouse
Chair (Assistant desk/Vehicle Warehouse office/Bunker desk/Hangar office)

MAP FIX DLC PACK FEATURES
Fixed window at Michael's house
Doors at the Bahama Mamas West (inside)
Water for the Heist and Gunrunning Yacht jacuzzi
Shutter at the Lombank, Maze Bank West and Maze Bank Tower Office garages (they will unload automatically when the player is near)

REQUIREMENTS
Latest game version (1290.1)
Latest Script Hook V
Latest Script Hook V NET
Open Interiors (Make sure to use the OpenInteriors.ini I provided, or open OpenInteriors.ini to change "loadMultiplayerMap=0" to "loadMultiplayerMap=1" and change "addInteriorBlipsAtStartup=1" to "addInteriorBlipsAtStartup=0".)

OPTIONAL REQUIREMENTS (needed for the Map Fix DLC Pack)
OpenIV.ASI
Mods folder

OPTIONAL SCRIPTS
Single Player Apartment
Yacht Deluxe
Simple Trainer

INSTALLATION
Move OnlineInteriors.dll and OnlineInteriors.ini into the scripts folder in your GTA V directory.

NOTE: If you have the old version by Alex106, make sure you remove the OnlineInteriors.cs, OnlineInteriorsProps.cs and OfficeAssistant.cs files from your scripts folder
Downloaded @ Blackout1911.deviantart.com

Simply copy into "Skins"-Folder from rainmeter

if you don't have the calibri font, ask google ^^